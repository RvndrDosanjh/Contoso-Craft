﻿using ContosoCrafts.WebSite.Models;
using ContosoCrafts.WebSite.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContosoCrafts.WebSite.Services
{
    public class JsonFileProductService
    {
        internal IEmunirable<Product> GetProducts()
        {
            throw new NotImplementedException();
        }
    }
}
