﻿namespace ContosoCrafts.WebSite.Pages
{
    internal class set
    {
    }
}