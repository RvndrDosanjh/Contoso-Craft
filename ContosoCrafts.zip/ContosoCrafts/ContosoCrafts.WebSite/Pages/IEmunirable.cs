﻿namespace ContosoCrafts.WebSite.Pages
{
    internal interface IEmunirable<T>
    {
    }
}